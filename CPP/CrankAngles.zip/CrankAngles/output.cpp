#include "swz_3rrs.h"
#include <math.h>
#include <fstream>

using namespace std;

void output(double zmin, double zmax, double params*)
{

	double alpha = 0, beta = 0, heave = zmin; // alpha and beta are roll and pitch respectively
	double sol1[2],sol2[2],sol3[2]; // variables to store inverse kinematics values: 0th variable is active joint angle and 1th variable is passive joint angle (in radians)
	double param[] = {.407,.323,.650,.806, heave};

	// Opening text file to store gravity values
	myfile.open ("data.txt");	  

	for(double i=zmin; i<=zmax; i+=0.0005)
	{
		swz_3rrs_invkin1(alpha,beta,param, sol1);
		swz_3rrs_invkin2(alpha,beta,param, sol2);
		swz_3rrs_invkin3(alpha,beta,param, sol3); 		
		myfile<<sol1[0]<<'\t'<<sol2[0]<<'\t'<<sol3[0]<<'\n';
	}
	myfile.close();	 

}