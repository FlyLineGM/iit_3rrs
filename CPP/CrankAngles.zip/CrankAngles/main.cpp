#include <iostream>
#include <cmath>
//#include "swz_len.h"
#include "swz_3rrs.h"

using namespace std;

int main()
{

	double zmin = 0.4, zmax = 0.5; // minimum and maximum heave
	int N = 500; // Number of points

	double param[] = {.407,.323,.650,.806, zmin}; // parameters that define the link legths of the manipulator

	output(zmin, zmax, N, param);

	return 0;
}
